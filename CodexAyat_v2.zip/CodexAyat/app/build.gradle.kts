plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

val ksPath: String? = System.getenv("KEYSTORE_PATH")
val ksPass: String? = System.getenv("KS_PASS")

android {
    namespace = "com.codexayat.voice"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.codexayat.voice"
        minSdk = 26; targetSdk = 34
        // প্রতিবার GitHub Build নম্বর বাড়ে, তাই নতুন APK সবসময় পুরোনোটার ওপর ইনস্টল হবে
        versionCode = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull() ?: 1
        versionName = "0.7"
    }
    signingConfigs {
        create("codex") {
            if (ksPath != null && ksPass != null && File(ksPath).exists()) {
                storeFile = File(ksPath)
                storePassword = ksPass
                keyAlias = "codexayat"
                keyPassword = ksPass
            }
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            if (ksPath != null) signingConfig = signingConfigs.getByName("codex")
        }
    }
    buildFeatures { aidl = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.google.android.gms:play-services-ads:23.6.0")
}
