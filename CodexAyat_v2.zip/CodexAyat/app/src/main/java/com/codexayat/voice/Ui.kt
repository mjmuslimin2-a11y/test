package com.codexayat.voice

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val red = Color.parseColor("#E53935")
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()

    /** গ্লাস কার্ড: আধা-স্বচ্ছ ফিল + হালকা সাদা বর্ডার */
    fun glass(c: Context, radius: Int = 20, fill: Int = 0x26FFFFFF): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(c, radius).toFloat()
            setStroke(dp(c, 1), 0x40FFFFFF)
        }

    fun glassButton(c: Context, text: String, primary: Boolean = true): Button = Button(c).apply {
        this.text = text
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 15f
        stateListAnimator = null
        val colors = if (primary) intArrayOf(0xCCE53935.toInt(), 0xCCB71C1C.toInt())
        else intArrayOf(0x33FFFFFF, 0x1AFFFFFF)
        background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, colors).apply {
            cornerRadius = dp(c, 16).toFloat()
            setStroke(dp(c, 1), 0x55FFFFFF)
        }
        layoutParams = LinearLayout.LayoutParams(-1, dp(c, 50)).apply { topMargin = dp(c, 10) }
    }

    fun circleImage(c: Context, res: Int, sizeDp: Int): ImageView = ImageView(c).apply {
        setImageResource(res)
        scaleType = ImageView.ScaleType.CENTER_CROP
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
        }
        clipToOutline = true
        layoutParams = LinearLayout.LayoutParams(dp(c, sizeDp), dp(c, sizeDp))
    }

    /** ভয়েসের ছোট ছবি (না থাকলে 🎵) */
    fun thumbView(c: Context, bm: Bitmap?, sizeDp: Int): View {
        val s = dp(c, sizeDp)
        if (bm == null) {
            return TextView(c).apply {
                text = "🎵"; gravity = Gravity.CENTER; textSize = sizeDp * 0.45f
                background = glass(c, 10, 0x33FFFFFF)
                layoutParams = LinearLayout.LayoutParams(s, s)
            }
        }
        return ImageView(c).apply {
            setImageBitmap(bm)
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setRoundRect(0, 0, v.width, v.height, dp(c, 10).toFloat()) }
            }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(s, s)
        }
    }
}

/** বাটনে চাপলে ছোট চাপ-অ্যানিমেশন + পপ সাউন্ড */
fun View.onTap(sfx: Boolean = true, action: () -> Unit) {
    setOnClickListener {
        if (sfx) Sfx.pop()
        animate().scaleX(0.94f).scaleY(0.94f).setDuration(70).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(110).start()
            action()
        }.start()
    }
}

/** অ্যানিমেশন: ভিউ স্ক্রিনে থাকলেই চলে, সরে গেলে থামে */
object Anim {
    fun bind(v: View, a: Animator) {
        v.addOnAttachStateChangeListener(object : View.OnAttachStateChangeListener {
            override fun onViewAttachedToWindow(x: View) { a.start() }
            override fun onViewDetachedFromWindow(x: View) { a.cancel() }
        })
        if (v.isAttachedToWindow) a.start()
    }

    fun pulse(v: View, to: Float = 1.05f, ms: Long = 1100) {
        bind(v, ObjectAnimator.ofPropertyValuesHolder(v,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, to),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, to)).apply {
            duration = ms; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        })
    }

    fun float(v: View, dy: Float, ms: Long = 1800) {
        bind(v, ObjectAnimator.ofFloat(v, View.TRANSLATION_Y, -dy, dy).apply {
            duration = ms; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        })
    }

    fun wiggle(v: View, deg: Float = 8f, ms: Long = 900) {
        bind(v, ObjectAnimator.ofFloat(v, View.ROTATION, -deg, deg).apply {
            duration = ms; repeatCount = ValueAnimator.INFINITE; repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
        })
    }

    /** লেখার ওপর দিয়ে আলোর ঝিলিক */
    fun shimmer(tv: TextView) {
        val w = tv.paint.measureText(tv.text.toString()).coerceAtLeast(60f)
        val a = ValueAnimator.ofFloat(-w, w * 2).apply {
            duration = 2400; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
            addUpdateListener {
                val x = it.animatedValue as Float
                tv.paint.shader = LinearGradient(x, 0f, x + w, 0f,
                    intArrayOf(0xFFFFFFFF.toInt(), 0xFFFF5252.toInt(), 0xFFFFFFFF.toInt()),
                    floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP)
                tv.invalidate()
            }
        }
        bind(tv, a)
    }

    fun appear(v: View, delay: Long = 0, dy: Float = 40f) {
        v.alpha = 0f; v.translationY = dy
        v.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(380).start()
    }
}

/** ঝাপসা লাল আলোর ব্যাকগ্রাউন্ড (গ্লাস ইফেক্টের পেছনে) */
class BgView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        cv.drawColor(0xFF0A0708.toInt())
        glow(cv, width * 0.95f, height * 0.06f, width * 0.85f, 0x77E53935)
        glow(cv, width * 0.02f, height * 0.92f, width * 0.95f, 0x66B71C1C)
        glow(cv, width * 0.15f, height * 0.42f, width * 0.55f, 0x22FFFFFF)
    }
    private fun glow(cv: Canvas, x: Float, y: Float, r: Float, color: Int) {
        p.shader = RadialGradient(x, y, r, color, color and 0x00FFFFFF, Shader.TileMode.CLAMP)
        cv.drawCircle(x, y, r, p)
    }
}

/** স্প্ল্যাশ স্ক্রিনের লোগোর চারদিকে ঘূর্ণায়মান রিং ও ঢেউ */
class RingsView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    private var t = 0f
    private val rect = RectF()
    private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 2200; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); anim.start() }
    override fun onDetachedFromWindow() { anim.cancel(); super.onDetachedFromWindow() }

    override fun onDraw(cv: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f; val cy = height / 2f
        val base = minOf(width, height) / 2f
        for (i in 0..2) {
            val ph = (t + i / 3f) % 1f
            p.strokeWidth = 2.5f * d
            p.color = Color.argb((170 * (1f - ph)).toInt(), 229, 57, 53)
            cv.drawCircle(cx, cy, base * 0.15f + base * 0.8f * ph, p)
        }
        p.strokeWidth = 4f * d
        p.color = 0xFFFF5252.toInt()
        val r1 = base * 0.45f
        rect.set(cx - r1, cy - r1, cx + r1, cy + r1)
        cv.drawArc(rect, t * 360f, 70f, false, p)
        cv.drawArc(rect, t * 360f + 180f, 70f, false, p)
        p.strokeWidth = 3f * d
        p.color = 0xFFFFFFFF.toInt()
        val r2 = base * 0.6f
        rect.set(cx - r2, cy - r2, cx + r2, cy + r2)
        cv.drawArc(rect, -t * 540f, 40f, false, p)
        cv.drawArc(rect, -t * 540f + 120f, 40f, false, p)
        cv.drawArc(rect, -t * 540f + 240f, 40f, false, p)
    }
}
