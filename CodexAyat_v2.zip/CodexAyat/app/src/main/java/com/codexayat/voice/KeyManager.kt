package com.codexayat.voice

import android.content.Context
import java.security.SecureRandom

/** র‍্যান্ডম কী তৈরি + ২৪ ঘণ্টার মেয়াদ। (এখন ফোনের ভেতরেই; পরে সার্ভার যোগ করা যাবে) */
object KeyManager {
    private const val CHARS = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private fun p(c: Context) = c.getSharedPreferences("key", Context.MODE_PRIVATE)

    fun newPending(c: Context): String {
        val r = SecureRandom()
        fun seg() = (1..4).map { CHARS[r.nextInt(CHARS.length)] }.joinToString("")
        val k = "AYAT-${seg()}-${seg()}-${seg()}"
        p(c).edit().putString("pending", k).apply()
        return k
    }

    fun pending(c: Context): String? = p(c).getString("pending", null)

    fun tryLogin(c: Context, input: String): Boolean {
        val k = pending(c) ?: return false
        if (input.trim().uppercase() != k) return false
        val now = System.currentTimeMillis()
        p(c).edit().putLong("expiry", now + Config.KEY_HOURS * 3600_000L)
            .putLong("seen", now).remove("pending").apply()
        return true
    }

    fun remainingMs(c: Context): Long {
        val sp = p(c)
        val exp = sp.getLong("expiry", 0L)
        if (exp == 0L) return 0L
        val now = System.currentTimeMillis()
        val seen = sp.getLong("seen", 0L)
        if (now < seen - 60_000L) { // ফোনের সময় পেছানো হয়েছে
            sp.edit().putLong("expiry", 0L).apply()
            return 0L
        }
        if (now > seen) sp.edit().putLong("seen", now).apply()
        return maxOf(0L, exp - now)
    }

    fun isValid(c: Context) = remainingMs(c) > 0L
    fun logout(c: Context) { p(c).edit().putLong("expiry", 0L).apply() }
}
