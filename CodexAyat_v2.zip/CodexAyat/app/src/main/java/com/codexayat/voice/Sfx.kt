package com.codexayat.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack

/** ছোট "পপ" সাউন্ড (কোনো ফাইল লাগে না, কোডেই বানানো) */
object Sfx {
    private const val SR = 22050
    private val data: ShortArray by lazy {
        val n = SR * 90 / 1000
        ShortArray(n) { i ->
            val t = i.toDouble() / SR
            val f = 1100.0 - 6000.0 * t
            val env = Math.exp(-t * 38.0)
            (Math.sin(2 * Math.PI * f * t) * env * 8000).toInt().toShort()
        }
    }

    fun pop() {
        Thread {
            try {
                val d = data
                val t = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                    .setAudioFormat(AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setBufferSizeInBytes(d.size * 2)
                    .setTransferMode(AudioTrack.MODE_STATIC).build()
                t.write(d, 0, d.size)
                t.play()
                Thread.sleep(180)
                t.release()
            } catch (_: Throwable) {}
        }.start()
    }
}
