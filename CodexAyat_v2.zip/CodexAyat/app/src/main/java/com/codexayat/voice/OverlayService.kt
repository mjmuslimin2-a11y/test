package com.codexayat.voice

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/** গেমের ওপর ভাসমান ছোট বাবল + ভয়েস তালিকা + নিচে অনার-লেখা। */
class OverlayService : Service() {
    companion object {
        @Volatile var running = false
        const val ACTION_STOP = "com.codexayat.voice.STOP"
        private const val CH = "overlay"
        private const val OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    }

    private lateinit var wm: WindowManager
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var ring: FrameLayout? = null
    private var panel: View? = null
    private var label: View? = null
    private val main = Handler(Looper.getMainLooper())

    private var micOn = false
    private var playingItem: AudioLibrary.Item? = null
    private var micBtn: TextView? = null
    private var npBar: View? = null
    private var npIcon: FrameLayout? = null
    private var npName: TextView? = null
    private val endRunnable = Runnable { clearNowPlaying() }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun screenW(): Int = try {
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.width() else resources.displayMetrics.widthPixels
    } catch (_: Throwable) { resources.displayMetrics.widthPixels }
    private fun screenH(): Int = try {
        if (Build.VERSION.SDK_INT >= 30) wm.currentWindowMetrics.bounds.height() else resources.displayMetrics.heightPixels
    } catch (_: Throwable) { resources.displayMetrics.heightPixels }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        if (intent?.action == ACTION_STOP || !KeyManager.isValid(this) || !Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY
        }
        if (!running) { running = true; setup() }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(Config.BRAND)
            .setContentText("ওভারলে চালু আছে")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stat), "বন্ধ করুন", stop).build())
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    // ---------- সেটআপ ----------
    private fun setup() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        ShizukuBridge.connect(this)

        // নিচের অনার-লেখা: হালকা, টাচ নেয় না, গেমে বাধা দেয় না
        val lbl = TextView(this).apply {
            text = Config.OWNER
            setTextColor(0xB3FFFFFF.toInt()); textSize = 11f; letterSpacing = 0.06f
            setShadowLayer(5f, 0f, 0f, 0xCC000000.toInt())
            setPadding(dp(8), dp(2), dp(8), dp(2))
        }
        val llp = WindowManager.LayoutParams(-2, -2, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(Config.LABEL_BOTTOM_DP)
        }
        wm.addView(lbl, llp); label = lbl

        // ছোট ভাসমান বাবল (যেকোনো জায়গায় টেনে রাখা যায়, স্ক্রিনের বাইরে যায় না)
        val r = FrameLayout(this).apply {
            setPadding(dp(2), dp(2), dp(2), dp(2))
            alpha = 0.85f
            addView(Ui.circleImage(this@OverlayService, R.drawable.logo, 44))
        }
        ring = r
        setBubbleActive(false)
        bubbleLp = WindowManager.LayoutParams(dp(48), dp(48), OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(8); y = dp(160) }

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        r.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = bubbleLp.x; oy = bubbleLp.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (!moved && (abs(dx) > dp(6) || abs(dy) > dp(6))) { moved = true; hidePanel() }
                    if (moved) {
                        bubbleLp.x = (ox + dx.toInt()).coerceIn(0, maxOf(0, screenW() - dp(48)))
                        bubbleLp.y = (oy + dy.toInt()).coerceIn(0, maxOf(0, screenH() - dp(48)))
                        try { wm.updateViewLayout(r, bubbleLp) } catch (_: Throwable) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); true }
                else -> false
            }
        }
        wm.addView(r, bubbleLp)
        toast("ওভারলে চালু — গেমে গিয়ে বাবলে চাপুন")
    }

    private fun setBubbleActive(active: Boolean) {
        ring?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(0x33000000)
            setStroke(dp(2), if (active) 0xFFE53935.toInt() else 0x99FFFFFF.toInt())
        }
        ring?.alpha = if (active) 1f else 0.85f
    }

    private fun clampBubble() {
        val r = ring ?: return
        bubbleLp.x = bubbleLp.x.coerceIn(0, maxOf(0, screenW() - dp(48)))
        bubbleLp.y = bubbleLp.y.coerceIn(0, maxOf(0, screenH() - dp(48)))
        try { wm.updateViewLayout(r, bubbleLp) } catch (_: Throwable) {}
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (ring != null) { hidePanel(); clampBubble() }
    }

    // ---------- প্যানেল ----------
    private fun togglePanel() { if (panel != null) hidePanel() else showPanel() }

    private fun hidePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Throwable) {} }
        panel = null; micBtn = null; npBar = null; npIcon = null; npName = null
    }

    private fun tap(v: View, action: () -> Unit) {
        if (Config.POP_IN_OVERLAY) v.onTap(true, action) else v.setOnClickListener { action() }
    }

    private fun updateMicBtn() {
        micBtn?.apply {
            text = if (micOn) "🎤 ON" else "🎤 OFF"
            background = Ui.glass(this@OverlayService, 12, if (micOn) 0x99E53935.toInt() else 0x33FFFFFF)
        }
    }

    private fun toggleMic() {
        if (!micOn) {
            if (!ShizukuBridge.granted()) { toast("Shizuku চালু নেই বা পারমিশন নেই"); return }
            ShizukuBridge.connect(this)
            micOn = true
        } else micOn = false
        stopAll(); clearNowPlaying()
        updateMicBtn()
    }

    private fun showPanel() {
        clampBubble()
        val w = dp(236)
        val items = AudioLibrary.list(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = Ui.glass(this@OverlayService, 18, 0xEE120A0C.toInt())
        }

        // ওপরের সারি: বামে মাইক, মাঝে নাম, ডানে ✕
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val mic = TextView(this).apply {
            textSize = 12f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(9), dp(5), dp(9), dp(5))
        }
        tap(mic) { toggleMic() }
        micBtn = mic; updateMicBtn()
        head.addView(mic)
        head.addView(TextView(this).apply {
            text = Config.BRAND; setTextColor(Color.WHITE); textSize = 14f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER; layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        })
        val close = TextView(this).apply {
            text = "✕"; setTextColor(Color.WHITE); textSize = 16f; setPadding(dp(8), dp(4), dp(4), dp(4))
        }
        tap(close) { hidePanel() }
        head.addView(close)
        box.addView(head)
        box.addView(TextView(this).apply {
            text = "OFF: শুধু আপনি শুনবেন  •  ON: টিম শুনবে"
            setTextColor(0x99FFFFFF.toInt()); textSize = 10f; gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(2))
        })

        // ভয়েস তালিকা: বামে ছবি, ডানে নাম
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (items.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "ভয়েস নেই — অ্যাপ খুলে ভয়েস যোগ করুন"; setTextColor(0xFFBBBBBB.toInt()); textSize = 12f
                setPadding(0, dp(10), 0, dp(10))
            })
        }
        for (item in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(5), dp(8), dp(5))
                background = Ui.glass(this@OverlayService, 12, 0x1AFFFFFF)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) }
                setOnClickListener { play(item) }
            }
            row.addView(Ui.thumbView(this, AudioLibrary.thumb(this, item), 34))
            row.addView(TextView(this).apply {
                text = item.name; setTextColor(Color.WHITE); textSize = 13f; maxLines = 1
                ellipsize = TextUtils.TruncateAt.END; setPadding(dp(8), 0, dp(4), 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            row.addView(TextView(this).apply { text = "▶"; setTextColor(Ui.red); textSize = 15f })
            list.addView(row)
        }
        list.measure(View.MeasureSpec.makeMeasureSpec(w - dp(20), View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val listMax = minOf(dp(250), screenH() - dp(190)).coerceAtLeast(dp(90))
        val scroll = ScrollView(this).apply {
            addView(list)
            layoutParams = LinearLayout.LayoutParams(-1, minOf(list.measuredHeight, listMax))
        }
        box.addView(scroll)

        // নিচে: এখন কী চলছে (আইকন + নাম + থামান)
        val np = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8), dp(6), dp(8), dp(6))
            background = Ui.glass(this@OverlayService, 12, 0x33E53935)
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            visibility = View.GONE
        }
        val npI = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(28), dp(28)) }
        val npT = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 12f; maxLines = 1; ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0); layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val npStop = TextView(this).apply { text = "⏹"; textSize = 18f; setTextColor(Color.WHITE) }
        tap(npStop) { stopAll(); clearNowPlaying() }
        np.addView(npI); np.addView(npT); np.addView(npStop)
        box.addView(np)
        npBar = np; npIcon = npI; npName = npT
        showNowPlayingUi()

        val off = TextView(this).apply {
            text = "⛔ ওভারলে বন্ধ"; setTextColor(0xCCFFFFFF.toInt()); textSize = 11f; gravity = Gravity.CENTER
            setPadding(0, dp(10), 0, dp(2))
        }
        tap(off) { stopSelf() }
        box.addView(off)

        box.measure(View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED))
        val sw = screenW(); val sh = screenH()
        val lp = WindowManager.LayoutParams(w, -2, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (bubbleLp.x + dp(54) + w > sw) (bubbleLp.x - w - dp(6)).coerceAtLeast(0) else bubbleLp.x + dp(54)
            y = bubbleLp.y.coerceAtMost(maxOf(0, sh - box.measuredHeight - dp(8)))
        }
        wm.addView(box, lp); panel = box
    }

    // ---------- প্লে ----------
    private fun stopAll() { LocalPlayer.stop(); ShizukuBridge.stop() }

    private fun play(item: AudioLibrary.Item) {
        if (!KeyManager.isValid(this)) {
            toast("পাসওয়ার্ডের মেয়াদ শেষ। অ্যাপ খুলে নতুন পাসওয়ার্ড নিন।")
            stopSelf(); return
        }
        val f = AudioLibrary.file(this, item.id)
        if (!f.exists()) { toast("ফাইল পাওয়া যায়নি"); return }
        val ms = f.length() * 1000L / (Decoder.OUT_RATE * 2)
        stopAll()
        if (micOn) {
            if (ShizukuBridge.svc == null) {
                ShizukuBridge.connect(this); toast("Shizuku কানেক্ট হচ্ছে, আবার চাপুন"); return
            }
            ShizukuBridge.play(f) { msg ->
                if (!msg.contains("OK:")) main.post {
                    toast("❌ সমস্যা হয়েছে — অ্যাপ খুলে লগ কপি করে পাঠান")
                    clearNowPlaying()
                }
            }
        } else {
            LocalPlayer.play(f)
        }
        playingItem = item
        main.removeCallbacks(endRunnable)
        main.postDelayed(endRunnable, ms + 400)
        showNowPlayingUi()
        setBubbleActive(true)
    }

    private fun showNowPlayingUi() {
        val item = playingItem
        val bar = npBar ?: return
        if (item == null) { bar.visibility = View.GONE; return }
        bar.visibility = View.VISIBLE
        npName?.text = item.name
        npIcon?.removeAllViews()
        npIcon?.addView(Ui.thumbView(this, AudioLibrary.thumb(this, item), 28))
    }

    private fun clearNowPlaying() {
        playingItem = null
        main.removeCallbacks(endRunnable)
        showNowPlayingUi()
        setBubbleActive(false)
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacks(endRunnable)
        LocalPlayer.stop()
        ShizukuBridge.stop()
        hidePanel()
        listOf<View?>(ring, label).forEach { v -> v?.let { try { wm.removeView(it) } catch (_: Throwable) {} } }
        ring = null; label = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
