package com.codexayat.voice

/** এখানকার সব সেটিং আপনি নিজে বদলাতে পারবেন। */
object Config {
    const val BRAND = "𝐂𝐎𝐃𝐄𝐗 𝐀𝐘𝐀𝐓"
    const val OWNER = "𝐎𝐖𝐍𝐄𝐑 (𝐀𝐘𝐀𝐓 𝐕𝐀𝐈)"

    /** অ্যাপের ভার্সন নম্বর। প্রতিবার নতুন আপডেট দিলে এটা ১ করে বাড়ানো হবে (আমি বাড়িয়ে দেব)। */
    const val APP_VERSION = 2

    /** আপনার Firebase Realtime Database */
    const val FIREBASE_DB = "https://testffl-7aaa0-default-rtdb.firebaseio.com"

    const val TELEGRAM = "https://t.me/CODEX_AYAT"
    const val DEVELOPER_TG = "https://t.me/codexayat"
    const val YOUTUBE = "https://www.youtube.com/@codexayat"

    /** পাসওয়ার্ড কত ঘণ্টা চলবে */
    const val KEY_HOURS = 24L

    /** প্রতিটি লিংক খোলার পর কত সেকেন্ড অপেক্ষা করলে "সম্পন্ন" ধরা হবে */
    const val LINK_WAIT_SEC = 10L

    /** অনার-লেখা নেভিগেশন বারের কত dp ওপরে থাকবে (ছোট সংখ্যা = আরও নিচে) */
    const val LABEL_BOTTOM_DP = 3

    /** ভাসমান প্যানেলের বাটনে পপ সাউন্ড (স্পিকার থেকে মাইকে ঢুকে যেতে পারে, তাই বন্ধ রাখা ভালো) */
    const val POP_IN_OVERLAY = false
}
