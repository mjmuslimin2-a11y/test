package com.codexayat.voice

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

object Decoder {
    const val OUT_RATE = 48000

    fun decodeToPcm(ctx: Context, uri: Uri, out: File) {
        val ex = MediaExtractor()
        try { ex.setDataSource(ctx, uri, null); run(ex, out) } finally { ex.release() }
    }

    fun decodeFileToPcm(src: File, out: File) {
        val ex = MediaExtractor()
        try { ex.setDataSource(src.absolutePath); run(ex, out) } finally { ex.release() }
    }

    /** যেকোনো অডিওকে 48kHz, মনো, 16-bit PCM এ বদলে ফাইলে লেখে (সর্বোচ্চ ৩ মিনিট)। */
    private fun run(ex: MediaExtractor, out: File) {
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { idx = i; fmt = f; break }
        }
        require(idx >= 0) { "অডিও ট্র্যাক পাওয়া যায়নি" }
        ex.selectTrack(idx)
        val codec = MediaCodec.createDecoderByType(fmt!!.getString(MediaFormat.KEY_MIME)!!)
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val mono = ByteArrayOutputStream()
        try {
            codec.configure(fmt, null, null, 0)
            codec.start()
            val info = MediaCodec.BufferInfo()
            var inDone = false
            var outDone = false
            while (!outDone) {
                if (!inDone) {
                    val i = codec.dequeueInputBuffer(10000)
                    if (i >= 0) {
                        val b = codec.getInputBuffer(i)!!
                        val n = ex.readSampleData(b, 0)
                        if (n < 0) {
                            codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inDone = true
                        } else {
                            codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val o = codec.dequeueOutputBuffer(info, 10000)
                if (o >= 0) {
                    val b = codec.getOutputBuffer(o)!!
                    b.position(info.offset); b.limit(info.offset + info.size)
                    val sb = b.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    val frames = sb.remaining() / ch
                    for (f in 0 until frames) {
                        var s = 0
                        for (c in 0 until ch) s += sb.get().toInt()
                        val m = s / ch
                        mono.write(m and 0xff); mono.write((m shr 8) and 0xff)
                    }
                    codec.releaseOutputBuffer(o, false)
                    if (mono.size() > rate * 2 * 180) outDone = true
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
                } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
        } finally {
            try { codec.stop() } catch (_: Throwable) {}
            try { codec.release() } catch (_: Throwable) {}
        }

        val src = ByteBuffer.wrap(mono.toByteArray()).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val n = src.remaining()
        require(n > 0) { "ডিকোড করা অডিও খালি" }
        val outN = (n.toLong() * OUT_RATE / rate).toInt()
        val dst = ByteBuffer.allocate(outN * 2).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until outN) {
            val pos = i.toDouble() * rate / OUT_RATE
            val i0 = pos.toInt().coerceAtMost(n - 1)
            val i1 = (i0 + 1).coerceAtMost(n - 1)
            val fr = pos - i0
            dst.putShort((src.get(i0) * (1 - fr) + src.get(i1) * fr).toInt().toShort())
        }
        out.writeBytes(dst.array())
    }
}
