package com.codexayat.voice

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID

/** Firebase Realtime Database (REST): জোর-আপডেট যাচাই + মেম্বার গণনা */
object Remote {
    @Volatile var blocked = false
    @Volatile var message = ""
    @Volatile var updateUrl = Config.TELEGRAM
    @Volatile var adsLive = false
    @Volatile var adsEnabled = true
    @Volatile var adCount = 6

    private fun sp(c: Context) = c.getSharedPreferences("remote", Context.MODE_PRIVATE)

    private fun id(c: Context): String {
        var v = sp(c).getString("id", null)
        if (v == null) {
            v = UUID.randomUUID().toString().replace("-", "")
            sp(c).edit().putString("id", v).apply()
        }
        return v
    }

    private fun first(c: Context): Long {
        val f = sp(c).getLong("first", 0L)
        if (f != 0L) return f
        val now = System.currentTimeMillis()
        sp(c).edit().putLong("first", now).apply()
        return now
    }

    private fun http(method: String, path: String, body: String? = null): String? {
        var conn: HttpURLConnection? = null
        try {
            val cn = URL(Config.FIREBASE_DB + path).openConnection() as HttpURLConnection
            conn = cn
            cn.requestMethod = method
            cn.connectTimeout = 6000
            cn.readTimeout = 6000
            if (body != null) {
                cn.doOutput = true
                cn.setRequestProperty("Content-Type", "application/json")
                cn.outputStream.use { it.write(body.toByteArray()) }
            }
            return if (cn.responseCode in 200..299) cn.inputStream.bufferedReader().use { it.readText() } else null
        } catch (_: Throwable) {
            return null
        } finally {
            try { conn?.disconnect() } catch (_: Throwable) {}
        }
    }

    /** "আমি আছি" জানানো (শুধু এলোমেলো আইডি আর সময়, কোনো ব্যক্তিগত তথ্য নেই) */
    fun ping(c: Context) {
        val body = "{\"first\":${first(c)},\"last\":{\".sv\":\"timestamp\"},\"v\":${Config.APP_VERSION}}"
        http("PUT", "/members/${id(c)}.json", body)
    }

    /** config থেকে ন্যূনতম ভার্সন পড়ে blocked ঠিক করে। নেট না থাকলে কিছু বদলায় না। */
    fun fetchConfig() {
        val r = http("GET", "/config.json") ?: return
        try {
            if (r.trim() == "null") { blocked = false; return }
            val o = JSONObject(r)
            val min = o.optInt("min_version", 0)
            blocked = min > Config.APP_VERSION
            message = o.optString("message", "")
            val u = o.optString("url", "")
            updateUrl = if (u.isEmpty()) Config.TELEGRAM else u
            adsLive = o.optBoolean("ads_live", false)
            adsEnabled = o.optBoolean("ads_enabled", true)
            adCount = o.optInt("ads_count", 6).coerceIn(0, 10)
        } catch (_: Throwable) {}
    }

    private fun count(r: String?): Int? {
        if (r == null) return null
        return try { if (r.trim() == "null") 0 else JSONObject(r).length() } catch (_: Throwable) { null }
    }

    /** [মোট, এখন অনলাইন (৩ মিনিট), ২৪ ঘণ্টায় সক্রিয়] */
    fun stats(): IntArray? {
        val total = count(http("GET", "/members.json?shallow=true")) ?: return null
        val now = System.currentTimeMillis()
        val online = count(http("GET", "/members.json?orderBy=%22last%22&startAt=${now - 180_000L}")) ?: return null
        val day = count(http("GET", "/members.json?orderBy=%22last%22&startAt=${now - 86_400_000L}")) ?: return null
        return intArrayOf(total, online, day)
    }
}
