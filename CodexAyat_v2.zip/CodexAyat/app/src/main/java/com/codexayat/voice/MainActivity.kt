package com.codexayat.voice

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.security.SecureRandom

class MainActivity : Activity() {
    private lateinit var col: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private var screen = ""
    private var importTv: TextView? = null
    @Volatile private var importMsg = ""

    private var adsDone: Int
        get() = getSharedPreferences("tasks", MODE_PRIVATE).getInt("done", 0)
        set(v) { getSharedPreferences("tasks", MODE_PRIVATE).edit().putInt("done", v).apply() }
    private var adFail = 0
    private var adBusy = false

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, r ->
        if (r == PackageManager.PERMISSION_GRANTED) ShizukuBridge.connect(this)
        refreshHome()
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { ShizukuBridge.connect(this); refreshHome() }

    private fun dp(v: Int) = Ui.dp(this, v)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun refreshHome() = runOnUiThread { if (screen == "home") home() }

    // ---------- helpers ----------
    private fun tv(text: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false, center: Boolean = false) =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            if (center) gravity = Gravity.CENTER
        }

    private fun card(delay: Long = 0): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = Ui.glass(this@MainActivity)
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(14) }
        Anim.appear(this, delay)
    }

    private fun button(text: String, primary: Boolean = true, onClick: () -> Unit): View =
        Ui.glassButton(this, text, primary).apply { onTap(true, onClick); Anim.appear(this, 0, 20f) }

    private fun reset() {
        handler.removeCallbacksAndMessages(null)
        importTv = null
        col.removeAllViews()
        val logo = Ui.circleImage(this, R.drawable.logo, 96)
        col.addView(logo)
        Anim.float(logo, dp(4).toFloat())
        Anim.pulse(logo, 1.06f, 1500)
        val brand = tv(Config.BRAND, 26f, bold = true, center = true).apply { setPadding(0, dp(8), 0, 0) }
        col.addView(brand)
        Anim.shimmer(brand)
        var taps = 0
        var lastTap = 0L
        brand.setOnClickListener {
            val now = System.currentTimeMillis()
            if (now - lastTap > 2000) taps = 0
            lastTap = now
            taps++
            if (taps >= 7) { taps = 0; showStats() }
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val host = FrameLayout(this)
        host.addView(BgView(this))
        col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(40), dp(20), dp(30))
        }
        host.addView(ScrollView(this).apply { isFillViewport = true; addView(col) })
        val splash = buildSplash()
        host.addView(splash)
        setContentView(host)
        host.post {
            try {
                Shizuku.addRequestPermissionResultListener(permListener)
                Shizuku.addBinderReceivedListenerSticky(binderListener)
            } catch (_: Throwable) {}
            ShizukuBridge.onChange = { refreshHome() }
            Ads.init(applicationContext)
            route()
            startBundledImport()
        }
        host.postDelayed({
            splash.animate().alpha(0f).setDuration(350).withEndAction { host.removeView(splash) }.start()
        }, 1800)
    }

    // ---------- স্প্ল্যাশ: লোগো + চারদিকে অ্যানিমেশন + নিচে নাম ----------
    private fun buildSplash(): View {
        val v = FrameLayout(this).apply { isClickable = true }
        v.addView(BgView(this))
        val colm = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        val holder = FrameLayout(this).apply { layoutParams = LinearLayout.LayoutParams(dp(300), dp(300)) }
        holder.addView(RingsView(this), FrameLayout.LayoutParams(-1, -1))
        val logo = Ui.circleImage(this, R.drawable.logo, 120)
        holder.addView(logo, FrameLayout.LayoutParams(dp(120), dp(120), Gravity.CENTER))
        Anim.pulse(logo, 1.07f, 900)
        colm.addView(holder)
        val name = tv(Config.BRAND, 28f, bold = true, center = true)
        colm.addView(name)
        Anim.shimmer(name)
        colm.addView(tv("Loading...", 12f, 0x99FFFFFF.toInt(), center = true).apply { setPadding(0, dp(8), 0, 0) })
        v.addView(colm, FrameLayout.LayoutParams(-1, -1))
        v.addView(tv(Config.OWNER, 12f, 0xAAFFD54F.toInt(), center = true),
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(36) })
        return v
    }

    private fun route() {
        if (Remote.blocked) updateScreen()
        else if (KeyManager.isValid(this)) home() else login()
    }

    private val pingH = Handler(Looper.getMainLooper())
    private val pingTick = object : Runnable {
        override fun run() { checkRemote(); pingH.postDelayed(this, 90_000) }
    }

    override fun onResume() {
        super.onResume()
        if (Remote.blocked) updateScreen()
        else if (screen == "home") { if (KeyManager.isValid(this)) home() else login() }
        pingH.removeCallbacks(pingTick)
        pingH.post(pingTick)
    }

    override fun onPause() { super.onPause(); pingH.removeCallbacks(pingTick) }

    /** নেট থাকলে: "আমি আছি" জানায় + নতুন আপডেট আবশ্যক কি না দেখে */
    private fun checkRemote() {
        Thread {
            Remote.ping(this)
            Remote.fetchConfig()
            runOnUiThread {
                if (Remote.blocked) { stopOverlay(); if (screen != "update") updateScreen() }
                else if (screen == "update") route()
            }
        }.start()
    }

    private fun updateScreen() {
        screen = "update"; reset()
        val c = card(); col.addView(c)
        c.addView(tv("⚠️ Update Required", 20f, bold = true, center = true))
        c.addView(tv("আপডেট দিয়ে আসুন", 16f, 0xFFFFD54F.toInt(), center = true).apply { setPadding(0, dp(6), 0, dp(10)) })
        val m = Remote.message.ifEmpty { "A new version is available.\nনতুন ভার্সন এসেছে। আপডেট করতে আমাদের Telegram চ্যানেলে যান।" }
        c.addView(tv(m, 14f, 0xFFDDDDDD.toInt(), center = true))
        c.addView(button("⬇️ Update Now") { openUrl(Remote.updateUrl) })
        col.addView(tv(Config.OWNER, 13f, 0xFFFFD54F.toInt(), center = true).apply { setPadding(0, dp(22), 0, 0) })
    }

    /** লোগোর নামে ৭ বার চাপলে মেম্বার সংখ্যা দেখায় (শুধু আপনি জানবেন) */
    private fun showStats() {
        toast("Loading stats...")
        Thread {
            val st = Remote.stats()
            runOnUiThread {
                val msg = if (st == null) "Could not load.\nCheck internet and Firebase rules."
                else "👥 Total members: ${st[0]}\n🟢 Online now (3 min): ${st[1]}\n📅 Active in 24h: ${st[2]}"
                android.app.AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                    .setTitle("CODEX AYAT — Stats").setMessage(msg).setPositiveButton("OK", null).show()
            }
        }.start()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ShizukuBridge.onChange = null
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    // ---------- অ্যাপের ভেতরের ভয়েস প্যাক (assets/voices.zip) ----------
    private fun setImport(s: String) {
        importMsg = s
        runOnUiThread { importTv?.text = s; importTv?.visibility = if (s.isEmpty()) View.GONE else View.VISIBLE }
    }

    private fun startBundledImport() {
        Thread {
            try {
                val n = AudioLibrary.importBundled(this) { done, total -> setImport("ভয়েস প্রস্তুত হচ্ছে $done/$total ...") }
                setImport("")
                if (n > 0) runOnUiThread { toast("$n টি ভয়েস যোগ হয়েছে"); refreshHome() }
            } catch (_: Throwable) { setImport("") }
        }.start()
    }

    // ---------- একই স্টাইলের বক্স (Telegram / YouTube / Task) ----------
    private class Brand(val root: LinearLayout, val status: TextView)

    private fun linkBox(iconRes: Int, accent: Int, title: String, subtitle: String, withStatus: Boolean,
                        wiggleIcon: Boolean, onOpen: () -> Unit): Brand {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf((accent and 0x00FFFFFF) or 0x55000000, 0x22FFFFFF)).apply {
                cornerRadius = dp(18).toFloat(); setStroke(dp(2), accent)
            }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        }
        val icon = ImageView(this).apply {
            setImageResource(iconRes)
            layoutParams = LinearLayout.LayoutParams(dp(42), dp(42))
        }
        root.addView(icon)
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), 0, dp(8), 0)
            layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
        }
        val name = tv(title, 17f, bold = true)
        mid.addView(name)
        if (subtitle.isNotEmpty()) mid.addView(tv(subtitle, 12f, 0xDDFFFFFF.toInt()))
        root.addView(mid)
        val status = tv("", 13f, 0xFFDDDDDD.toInt(), true).apply { visibility = if (withStatus) View.VISIBLE else View.GONE }
        root.addView(status)
        root.onTap(true, onOpen)
        Anim.appear(root, 0, 30f)
        Anim.shimmer(name)
        if (wiggleIcon) Anim.wiggle(icon, 7f, 1000) else Anim.pulse(icon, 1.12f, 800)
        return Brand(root, status)
    }

    private fun brandButton(isTg: Boolean, withStatus: Boolean, onOpen: () -> Unit): Brand =
        linkBox(if (isTg) R.drawable.ic_telegram else R.drawable.ic_youtube,
            if (isTg) 0xFF2AABEE.toInt() else 0xFFFF0000.toInt(),
            Config.BRAND,
            if (isTg) "Telegram চ্যানেলে জয়েন করুন" else "YouTube চ্যানেল সাবস্ক্রাইব করুন",
            withStatus, isTg, onOpen)

    private fun openUrl(u: String) {
        try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) } catch (_: Throwable) { toast("লিংক খোলা যায়নি") }
    }

    // ---------- লগইন ----------
    private fun login() {
        screen = "login"; reset()
        val c = card(); col.addView(c)
        c.addView(tv("🔐 লগইন", 20f, bold = true, center = true))
        c.addView(tv("আপনার পাসওয়ার্ড লিখুন", 13f, 0xFFCCCCCC.toInt(), center = true).apply { setPadding(0, dp(4), 0, dp(10)) })
        val input = EditText(this).apply {
            hint = "AYAT-XXXX-XXXX-XXXX"
            setHintTextColor(0x77FFFFFF); setTextColor(Color.WHITE)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            setSingleLine(); gravity = Gravity.CENTER; typeface = Typeface.MONOSPACE
            background = Ui.glass(this@MainActivity, 14, 0x1AFFFFFF)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setText(KeyManager.pending(this@MainActivity) ?: "")
        }
        c.addView(input)
        c.addView(button("লগইন") {
            if (KeyManager.tryLogin(this, input.text.toString())) { toast("✅ লগইন সফল"); home() }
            else toast("❌ পাসওয়ার্ড ভুল বা পুরোনো")
        })
        c.addView(button("🔑 পাসওয়ার্ড নিন (Get Password)", false) { getPasswordScreen() })
        col.addView(tv(Config.OWNER, 13f, 0xFFFFD54F.toInt(), center = true).apply { setPadding(0, dp(22), 0, 0) })
        col.addView(linkBox(R.drawable.ic_telegram, 0xFF2AABEE.toInt(), "Developer", "", false, true) {
            openUrl(Config.DEVELOPER_TG)
        }.root)
    }

    // ---------- Get Password ----------
    private fun startAdTask(need: Int, st: TextView) {
        if (adBusy || adsDone >= need) return
        adBusy = true
        st.text = "⏳"
        Ads.showRewarded(this) { res ->
            adBusy = false
            when (res) {
                1 -> { adFail = 0; adsDone = adsDone + 1; toast("✅ Task ${adsDone}/$need") }
                0 -> toast("পুরো ad দেখতে হবে — আবার চাপুন")
                else -> {
                    adFail++
                    if (adFail >= 3) { adFail = 0; adsDone = adsDone + 1; toast("Ad এখন পাওয়া যাচ্ছে না — task গণনা হলো") }
                    else toast("Ad লোড হয়নি — আবার চাপুন")
                }
            }
        }
    }

    private fun getPasswordScreen() {
        screen = "getpass"; reset()
        col.addView(tv("🔑 পাসওয়ার্ড নিন", 20f, bold = true, center = true).apply { setPadding(0, dp(14), 0, 0) })
        col.addView(tv("নিচের ধাপগুলো সম্পূর্ণ করুন", 13f, 0xFFCCCCCC.toInt(), center = true))
        val opened = HashMap<String, Long>()
        val tg = brandButton(true, true) { opened["tg"] = System.currentTimeMillis(); openUrl(Config.TELEGRAM) }
        val yt = brandButton(false, true) { opened["yt"] = System.currentTimeMillis(); openUrl(Config.YOUTUBE) }
        col.addView(tg.root); col.addView(yt.root)

        val need = if (Remote.adsEnabled) Remote.adCount else 0
        var stRef: TextView? = null
        val task: Brand? = if (need > 0) {
            val t = linkBox(R.drawable.ic_task, 0xFFFFB300.toInt(), "Task Complete", "Ad দেখে task পূর্ণ করুন", true, false) {
                stRef?.let { startAdTask(need, it) }
            }
            stRef = t.status
            t
        } else null
        if (task != null) col.addView(task.root)

        val gen = Ui.glassButton(this, "✨ পাসওয়ার্ড তৈরি করুন").apply {
            isEnabled = false; alpha = 0.5f
            onTap(true) { generateScreen() }
        }
        col.addView(gen)
        col.addView(button("← ফিরে যান", false) { login() })
        val tick = object : Runnable {
            override fun run() {
                var all = true
                for ((k, st) in listOf("tg" to tg.status, "yt" to yt.status)) {
                    val t = opened[k]
                    if (t == null) { st.text = "বাকি"; all = false }
                    else {
                        val e = (System.currentTimeMillis() - t) / 1000
                        if (e >= Config.LINK_WAIT_SEC) st.text = "✅"
                        else { st.text = "⏳${Config.LINK_WAIT_SEC - e}s"; all = false }
                    }
                }
                if (task != null) {
                    val d = adsDone
                    if (!adBusy) task.status.text = if (d >= need) "✅" else "$d/$need"
                    if (d < need) all = false
                }
                gen.isEnabled = all; gen.alpha = if (all) 1f else 0.5f
                handler.postDelayed(this, 700)
            }
        }
        handler.post(tick)
    }

    // ---------- পাসওয়ার্ড তৈরির অ্যানিমেশন ----------
    private fun generateScreen() {
        screen = "gen"; reset()
        val key = KeyManager.newPending(this)
        adsDone = 0; adFail = 0
        val c = card(); col.addView(c)
        val status = tv("", 15f, center = true)
        val keyTv = tv("", 22f, Color.WHITE, true, true).apply { typeface = Typeface.MONOSPACE; setPadding(0, dp(18), 0, dp(18)) }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100; progressTintList = ColorStateList.valueOf(Ui.red)
        }
        c.addView(status); c.addView(keyTv); c.addView(bar)
        val chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
        val rnd = SecureRandom()
        ValueAnimator.ofInt(0, 100).apply {
            duration = 3600
            addUpdateListener { a ->
                val p = a.animatedValue as Int
                bar.progress = p
                status.text = when { p < 30 -> "🔍 ভেরিফাই হচ্ছে..."; p < 70 -> "⚙️ পাসওয়ার্ড তৈরি হচ্ছে..."; else -> "🔐 প্রায় শেষ..." }
                val fixed = key.length * p / 100
                keyTv.text = buildString { for (i in key.indices) append(if (i < fixed || key[i] == '-') key[i] else chars[rnd.nextInt(chars.length)]) }
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(a: Animator) {
                    status.text = "✅ পাসওয়ার্ড তৈরি হয়েছে!"; keyTv.text = key
                    Anim.pulse(keyTv, 1.06f, 700)
                    col.addView(button("📋 কপি করুন", false) {
                        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("password", key))
                        toast("কপি হয়েছে")
                    })
                    col.addView(button("লগইন স্ক্রিনে যান →") { login() })
                }
            })
            start()
        }
    }

    // ---------- হোম ----------
    private fun home() {
        screen = "home"; reset()
        val rem = KeyManager.remainingMs(this)
        val h = rem / 3600_000L; val m = (rem / 60_000L) % 60
        col.addView(tv("⏳ Password expires in ${h}h ${m}m", 13f, 0xFFFFD54F.toInt(), center = true).apply { setPadding(0, dp(6), 0, 0) })

        // Shizuku
        val sc = card(0); col.addView(sc)
        sc.addView(tv("Shizuku", 16f, bold = true))
        sc.addView(tv(ShizukuBridge.status(), 13f, 0xFFDDDDDD.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        if (ShizukuBridge.alive() && !ShizukuBridge.granted())
            sc.addView(button("পারমিশন দিন", false) { ShizukuBridge.request() })
        if (ShizukuBridge.granted() && ShizukuBridge.svc == null)
            sc.addView(button("কানেক্ট করুন", false) { ShizukuBridge.connect(this); home() })

        // ওভারলে
        val oc = card(80); col.addView(oc)
        oc.addView(tv("ভাসমান বাবল", 16f, bold = true))
        val on = OverlayService.running
        oc.addView(tv(if (on) "✅ চালু আছে" else "বন্ধ", 13f, 0xFFDDDDDD.toInt()).apply { setPadding(0, dp(4), 0, 0) })
        oc.addView(button(if (on) "⛔ বন্ধ করুন" else "▶ চালু করুন") {
            if (on) { stopOverlay(); handler.postDelayed({ home() }, 300) } else startOverlay()
        })

        // ভয়েস লাইব্রেরি
        val lc = card(160); col.addView(lc)
        lc.addView(tv("🎧 ভয়েস লাইব্রেরি", 16f, bold = true))
        lc.addView(tv("▶ চাপলে শুধু আপনি শুনবেন (টিমে যায় না)", 11f, 0xFFBBBBBB.toInt()).apply { setPadding(0, dp(2), 0, 0) })
        val itv = tv(importMsg, 12f, 0xFFFFD54F.toInt()).apply {
            setPadding(0, dp(6), 0, 0); visibility = if (importMsg.isEmpty()) View.GONE else View.VISIBLE
        }
        importTv = itv
        lc.addView(itv)
        val items = AudioLibrary.list(this)
        if (items.isEmpty()) lc.addView(tv("এখনো কোনো ভয়েস নেই", 13f, 0xFFBBBBBB.toInt()).apply { setPadding(0, dp(8), 0, dp(4)) })
        for (item in items) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(7), dp(8), dp(7))
                background = Ui.glass(this@MainActivity, 12, 0x1AFFFFFF)
                layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) }
            }
            row.addView(Ui.thumbView(this, AudioLibrary.thumb(this, item), 38))
            row.addView(tv(item.name, 14f).apply {
                maxLines = 1; ellipsize = TextUtils.TruncateAt.END; setPadding(dp(10), 0, dp(6), 0)
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            row.addView(tv("▶", 18f, Ui.red).apply {
                setPadding(dp(12), dp(6), dp(12), dp(6))
                setOnClickListener { LocalPlayer.play(AudioLibrary.file(this@MainActivity, item.id)) }
            })
            row.addView(tv("🗑", 16f).apply {
                setPadding(dp(8), dp(6), dp(8), dp(6))
                onTap(true) { AudioLibrary.remove(this@MainActivity, item.id); home() }
            })
            lc.addView(row)
        }
        lc.addView(button("＋ ভয়েস / ZIP যোগ করুন") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("audio/*", "application/zip", "application/x-zip-compressed", "application/octet-stream"))
                putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            }, 1)
        })

        // Telegram
        col.addView(brandButton(true, false) { openUrl(Config.TELEGRAM) }.root)
        col.addView(button("লগআউট", false) { stopOverlay(); KeyManager.logout(this); login() })
        col.addView(tv(Config.OWNER, 13f, 0xFFFFD54F.toInt(), center = true).apply { setPadding(0, dp(18), 0, 0) })

        handler.postDelayed({ if (screen == "home") { if (KeyManager.isValid(this)) home() else login() } }, 60_000)
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            toast("\"অন্য অ্যাপের ওপর দেখান\" পারমিশন চালু করুন")
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
        ShizukuBridge.connect(this)
        startForegroundService(Intent(this, OverlayService::class.java))
        handler.postDelayed({ home() }, 500)
    }

    private fun stopOverlay() { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP)) }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req != 1 || res != RESULT_OK || data == null) return
        val uris = ArrayList<Uri>()
        data.data?.let { uris.add(it) }
        data.clipData?.let { cd -> for (i in 0 until cd.itemCount) uris.add(cd.getItemAt(i).uri) }
        setImport("প্রসেস হচ্ছে...")
        Thread {
            var added = 0
            var fail = 0
            for (u in uris.distinct()) {
                try {
                    val name = AudioLibrary.displayName(this, u).lowercase()
                    if (name.endsWith(".zip")) {
                        added += AudioLibrary.importZip(this, { contentResolver.openInputStream(u) }) { d, t -> setImport("ভয়েস প্রস্তুত হচ্ছে $d/$t ...") }
                    } else {
                        if (AudioLibrary.addFromUri(this, u) != null) added++
                    }
                } catch (_: Throwable) { fail++ }
            }
            setImport("")
            runOnUiThread {
                toast("$added টি ভয়েস যোগ হয়েছে" + if (fail > 0) " ($fail টি ব্যর্থ)" else "")
                home()
            }
        }.start()
    }
}
