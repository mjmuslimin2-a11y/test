package com.codexayat.voice

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import org.lsposed.hiddenapibypass.HiddenApiBypass
import java.io.FileInputStream
import kotlin.system.exitProcess

/** Shizuku-র মাধ্যমে shell প্রসেসে চলে। ক্লিপ চলার সময়টুকুতেই মাইক ইনপুটে অডিও ঢোকায়। */
class AudioService : IAudioService.Stub() {
    private var ctx: Context? = null
    private var track: AudioTrack? = null
    private var policy: Any? = null
    private var ht: HandlerThread? = null
    @Volatile private var playing = false
    @Volatile private var generation = 0
    private val log = StringBuilder()
    private fun l(s: String) { log.appendLine(s) }
    private val INT = Int::class.javaPrimitiveType

    override fun destroy() { stop(); exitProcess(0) }

    @Synchronized
    override fun stop() {
        generation++
        playing = false
        try { track?.stop(); track?.release() } catch (_: Throwable) {}
        track = null
        try {
            val c = ctx; val p = policy
            if (c != null && p != null) {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                AudioManager::class.java.getMethod("unregisterAudioPolicy", Class.forName("android.media.audiopolicy.AudioPolicy")).invoke(am, p)
            }
        } catch (_: Throwable) {}
        policy = null
        try { ht?.quitSafely() } catch (_: Throwable) {}
        ht = null
    }

    private fun rootOf(e: Throwable): Throwable =
        (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e

    // ActivityThread তৈরি করতে Looper-ওয়ালা থ্রেড লাগে (binder থ্রেডে Looper থাকে না)
    @Volatile private var loopHandler: android.os.Handler? = null

    private fun loopThread(): android.os.Handler {
        loopHandler?.let { return it }
        val ready = java.util.concurrent.CountDownLatch(1)
        val t = Thread {
            try {
                if (Looper.getMainLooper() == null) Looper.prepareMainLooper() else Looper.prepare()
            } catch (_: Throwable) { try { Looper.prepare() } catch (_: Throwable) {} }
            loopHandler = android.os.Handler(Looper.myLooper()!!)
            ready.countDown()
            Looper.loop()
        }
        t.isDaemon = true; t.name = "codex-looper"; t.start()
        ready.await()
        return loopHandler!!
    }

    @Suppress("UNCHECKED_CAST")
    private fun <T> onLoop(block: () -> T): T {
        val h = loopThread()
        var res: Any? = null
        var err: Throwable? = null
        val latch = java.util.concurrent.CountDownLatch(1)
        h.post {
            try { res = block() } catch (e: Throwable) { err = e } finally { latch.countDown() }
        }
        if (!latch.await(10, java.util.concurrent.TimeUnit.SECONDS)) throw IllegalStateException("looper timeout")
        val e = err
        if (e != null) throw e
        return res as T
    }

    private fun createContext(): Context {
        try {
            val at = Class.forName("android.app.ActivityThread")
            val ctor = at.getDeclaredConstructor(); ctor.isAccessible = true
            val inst = ctor.newInstance()
            at.getDeclaredField("sCurrentActivityThread").apply { isAccessible = true; set(null, inst) }
            at.getDeclaredField("mSystemThread").apply { isAccessible = true; setBoolean(inst, true) }
            return at.getMethod("getSystemContext").invoke(inst) as Context
        } catch (e: Throwable) { l("ctx-B: ${rootOf(e).stackTraceToString().take(400)}") }
        try {
            val at = Class.forName("android.app.ActivityThread")
            val sys = at.getMethod("systemMain").invoke(null)
            return at.getMethod("getSystemContext").invoke(sys) as Context
        } catch (e: Throwable) { l("ctx-A: ${rootOf(e).stackTraceToString().take(400)}") }
        throw IllegalStateException("system context পাওয়া যায়নি")
    }

    private fun systemContext(): Context {
        ctx?.let { return it }
        try { HiddenApiBypass.addHiddenApiExemptions("L") } catch (e: Throwable) { l("bypass: ${rootOf(e)}") }
        val c = onLoop { createContext() }
        ctx = c
        return c
    }

    @Synchronized
    override fun inject(pcm: ParcelFileDescriptor, sampleRate: Int): String {
        // binder কলের সময় "কলার" হিসেবে অ্যাপের uid ধরা হয়; shell-এর পারমিশন কাজে লাগাতে নিজের পরিচয়ে চালাতে হবে
        val token = android.os.Binder.clearCallingIdentity()
        try { return injectInternal(pcm, sampleRate) } finally { android.os.Binder.restoreCallingIdentity(token) }
    }

    private fun injectInternal(pcm: ParcelFileDescriptor, sampleRate: Int): String {
        log.setLength(0)
        try {
            stop()
            val c = systemContext()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(sampleRate)
                .setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()

            val ruleCls = Class.forName("android.media.audiopolicy.AudioMixingRule")
            val rbCls = Class.forName("android.media.audiopolicy.AudioMixingRule\$Builder")
            val rb = rbCls.getConstructor().newInstance()
            val matchPreset = ruleCls.getField("RULE_MATCH_ATTRIBUTE_CAPTURE_PRESET").getInt(null)
            for (preset in intArrayOf(1, 5, 6, 7)) { // MIC, CAMCORDER, VOICE_RECOGNITION, VOICE_COMMUNICATION
                val ab = AudioAttributes.Builder()
                AudioAttributes.Builder::class.java.getMethod("setInternalCapturePreset", INT).invoke(ab, preset)
                rbCls.getMethod("addMixRule", INT, Any::class.java).invoke(rb, matchPreset, ab.build())
            }
            try {
                val role = ruleCls.getField("MIX_ROLE_INJECTOR").getInt(null)
                rbCls.getMethod("setTargetMixRole", INT).invoke(rb, role)
            } catch (e: Throwable) { l("setTargetMixRole skipped: $e") }
            val rule = rbCls.getMethod("build").invoke(rb)

            val mixCls = Class.forName("android.media.audiopolicy.AudioMix")
            val mbCls = Class.forName("android.media.audiopolicy.AudioMix\$Builder")
            val mb = mbCls.getConstructor(ruleCls).newInstance(rule)
            mbCls.getMethod("setFormat", AudioFormat::class.java).invoke(mb, fmt)
            mbCls.getMethod("setRouteFlags", INT).invoke(mb, 2) // ROUTE_FLAG_LOOP_BACK
            val mix = mbCls.getMethod("build").invoke(mb)

            val polCls = Class.forName("android.media.audiopolicy.AudioPolicy")
            val pbCls = Class.forName("android.media.audiopolicy.AudioPolicy\$Builder")
            val pb = pbCls.getConstructor(Context::class.java).newInstance(c)
            pbCls.getMethod("addMix", mixCls).invoke(pb, mix)
            val thread = HandlerThread("codex-ap").also { it.start() }
            ht = thread
            pbCls.getMethod("setLooper", Looper::class.java).invoke(pb, thread.looper)
            val pol = pbCls.getMethod("build").invoke(pb)

            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val r = AudioManager::class.java.getMethod("registerAudioPolicy", polCls).invoke(am, pol) as Int
            l("registerAudioPolicy = $r (0 = সফল)")
            if (r != 0) { stop(); return log.toString() }
            policy = pol

            val t = (polCls.getMethod("createAudioTrackSource", mixCls).invoke(pol, mix) as? AudioTrack)
                ?: throw IllegalStateException("createAudioTrackSource null ফিরিয়েছে (পারমিশন/পলিসি রেডি না)")
            track = t
            t.play()
            playing = true
            val gen = ++generation
            val input = FileInputStream(pcm.fileDescriptor)
            Thread {
                val buf = ByteArray(4096)
                try {
                    while (playing && gen == generation) {
                        val n = input.read(buf)
                        if (n <= 0) break
                        t.write(buf, 0, n)
                    }
                } catch (_: Throwable) {
                } finally {
                    try { input.close(); pcm.close() } catch (_: Throwable) {}
                    if (gen == generation) { // স্বাভাবিকভাবে শেষ: বাকি অডিও বাজতে দিয়ে পলিসি সরানো
                        try { t.stop() } catch (_: Throwable) {}
                        try { Thread.sleep(400) } catch (_: Throwable) {}
                        if (gen == generation) stop()
                    }
                }
            }.start()
            l("OK: ইনজেকশন শুরু হয়েছে")
        } catch (e: Throwable) {
            l("ERROR: ${rootOf(e).stackTraceToString().take(1200)}")
            try { stop() } catch (_: Throwable) {}
        }
        return log.toString()
    }
}
