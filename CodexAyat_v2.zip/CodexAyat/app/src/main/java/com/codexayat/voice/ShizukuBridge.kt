package com.codexayat.voice

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import rikka.shizuku.Shizuku
import java.io.File

object ShizukuBridge {
    @Volatile var svc: IAudioService? = null
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var lastLog: String = ""
    @Volatile var connectFailed = false
    private var binding = false
    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private val timeoutRunnable = Runnable {
        if (svc == null && binding) {
            binding = false
            connectFailed = true
            onChange?.invoke()
        }
    }

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            h.removeCallbacks(timeoutRunnable)
            svc = IAudioService.Stub.asInterface(b); binding = false; connectFailed = false; onChange?.invoke()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null; binding = false; onChange?.invoke() }
    }

    fun alive() = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    fun granted() = try { alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    fun request() { try { Shizuku.requestPermission(100) } catch (_: Throwable) {} }

    fun connect(ctx: Context) {
        if (svc != null || binding || !granted()) return
        try {
            binding = true
            connectFailed = false
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, AudioService::class.java.name))
                .daemon(false).processNameSuffix("audio").debuggable(false).version(1)
            Shizuku.bindUserService(args, conn)
            h.removeCallbacks(timeoutRunnable)
            h.postDelayed(timeoutRunnable, 8000)
        } catch (_: Throwable) { binding = false; connectFailed = true }
    }

    fun status(): String = when {
        !alive() -> "❌ Shizuku বন্ধ — আগে Shizuku চালু করুন"
        !granted() -> "⚠️ Shizuku চালু, পারমিশন দেওয়া হয়নি"
        svc != null -> "✅ Shizuku রেডি"
        binding -> "⏳ সার্ভিস কানেক্ট হচ্ছে..."
        connectFailed -> "❌ কানেক্ট ব্যর্থ — Settings→Apps-এ Shizuku ও এই অ্যাপের Battery saver বন্ধ করুন, Autostart চালু করুন"
        else -> "⏳ কানেক্ট করুন চাপুন"
    }

    fun play(f: File, cb: (String) -> Unit) {
        val s = svc ?: return cb("সার্ভিস কানেক্টেড নেই")
        Thread {
            try {
                val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = s.inject(pfd, Decoder.OUT_RATE)
                lastLog = r; cb(r)
            } catch (e: Throwable) { lastLog = "ERROR: $e"; cb(lastLog) }
        }.start()
    }

    fun stop() { try { svc?.stop() } catch (_: Throwable) {} }
}
