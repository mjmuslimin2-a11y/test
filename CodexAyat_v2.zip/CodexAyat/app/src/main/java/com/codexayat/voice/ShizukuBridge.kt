package com.codexayat.voice

import android.content.ComponentName
import android.content.Context
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import android.os.ParcelFileDescriptor
import rikka.shizuku.Shizuku
import java.io.File

object ShizukuBridge {
    @Volatile var svc: IAudioService? = null
    @Volatile var onChange: (() -> Unit)? = null
    @Volatile var lastLog: String = ""
    private var binding = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(n: ComponentName, b: IBinder) {
            svc = IAudioService.Stub.asInterface(b); binding = false; onChange?.invoke()
        }
        override fun onServiceDisconnected(n: ComponentName) { svc = null; binding = false; onChange?.invoke() }
    }

    fun alive() = try { Shizuku.pingBinder() } catch (_: Throwable) { false }
    fun granted() = try { alive() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED } catch (_: Throwable) { false }
    fun request() { try { Shizuku.requestPermission(100) } catch (_: Throwable) {} }

    fun connect(ctx: Context) {
        if (svc != null || binding || !granted()) return
        try {
            binding = true
            val args = Shizuku.UserServiceArgs(ComponentName(ctx.packageName, AudioService::class.java.name))
                .daemon(false).processNameSuffix("audio").debuggable(false).version(1)
            Shizuku.bindUserService(args, conn)
        } catch (_: Throwable) { binding = false }
    }

    fun status(): String = when {
        !alive() -> "❌ Shizuku বন্ধ — আগে Shizuku চালু করুন"
        !granted() -> "⚠️ Shizuku চালু, পারমিশন দেওয়া হয়নি"
        svc == null -> "⏳ সার্ভিস কানেক্ট হচ্ছে..."
        else -> "✅ Shizuku রেডি"
    }

    fun play(f: File, cb: (String) -> Unit) {
        val s = svc ?: return cb("সার্ভিস কানেক্টেড নেই")
        Thread {
            try {
                val pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
                val r = s.inject(pfd, Decoder.OUT_RATE)
                lastLog = r; cb(r)
            } catch (e: Throwable) { lastLog = "ERROR: $e"; cb(lastLog) }
        }.start()
    }

    fun stop() { try { svc?.stop() } catch (_: Throwable) {} }
}
