package com.codexayat.voice

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.io.File
import java.io.FileInputStream

/** মাইক OFF মোড: শুধু আপনার ফোনে বাজে, টিমে যায় না */
object LocalPlayer {
    @Volatile private var gen = 0
    private var track: AudioTrack? = null

    @Synchronized
    fun play(f: File) {
        stop()
        val g = ++gen
        try {
            val min = AudioTrack.getMinBufferSize(Decoder.OUT_RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Decoder.OUT_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(min, 8192))
                .setTransferMode(AudioTrack.MODE_STREAM).build()
            track = t
            t.play()
            Thread {
                try {
                    FileInputStream(f).use { input ->
                        val buf = ByteArray(4096)
                        while (g == gen) {
                            val n = input.read(buf)
                            if (n <= 0) break
                            t.write(buf, 0, n)
                        }
                    }
                    if (g == gen) { try { t.stop() } catch (_: Throwable) {} }
                } catch (_: Throwable) {
                } finally {
                    try { t.release() } catch (_: Throwable) {}
                }
            }.start()
        } catch (_: Throwable) {}
    }

    @Synchronized
    fun stop() {
        gen++
        try { track?.stop() } catch (_: Throwable) {}
        track = null
    }
}
