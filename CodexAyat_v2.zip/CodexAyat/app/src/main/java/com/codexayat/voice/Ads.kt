package com.codexayat.voice

import android.app.Activity
import android.content.Context
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * Rewarded ads (AdMob).
 * Firebase config-এ ads_live = false থাকলে Google-এর টেস্ট অ্যাড দেখায় (নিরাপদ)।
 * ads_live = true করলে আপনার আসল অ্যাড ইউনিট চলে।
 */
object Ads {
    private const val TEST_REWARDED = "ca-app-pub-3940256099942544/5224354917"
    private val LIVE = listOf(
        "ca-app-pub-7467718022390683/6048535927",
        "ca-app-pub-7467718022390683/7990183889"
    )

    fun init(c: Context) {
        Thread { try { MobileAds.initialize(c) {} } catch (_: Throwable) {} }.start()
    }

    /** cb: 1 = reward পেয়েছে, 0 = মাঝপথে বন্ধ করেছে, -1 = অ্যাড লোড/দেখানো যায়নি */
    fun showRewarded(act: Activity, cb: (Int) -> Unit) {
        val ids = if (Remote.adsLive) LIVE else listOf(TEST_REWARDED)
        load(act, ids, 0, cb)
    }

    private fun load(act: Activity, ids: List<String>, i: Int, cb: (Int) -> Unit) {
        try {
            RewardedAd.load(act, ids[i], AdRequest.Builder().build(), object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    var earned = false
                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() { cb(if (earned) 1 else 0) }
                        override fun onAdFailedToShowFullScreenContent(e: AdError) { cb(-1) }
                    }
                    ad.show(act) { earned = true }
                }
                override fun onAdFailedToLoad(e: LoadAdError) {
                    if (i + 1 < ids.size) load(act, ids, i + 1, cb) else cb(-1)
                }
            })
        } catch (_: Throwable) { cb(-1) }
    }
}
