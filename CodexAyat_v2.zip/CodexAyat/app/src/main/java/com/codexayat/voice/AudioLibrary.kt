package com.codexayat.voice

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.InputStream
import java.util.UUID
import java.util.zip.ZipInputStream

/**
 * ভয়েস লাইব্রেরি। প্রতিটি ভয়েস = অডিও (PCM) + ঐচ্ছিক ছোট ছবি।
 * ZIP-এর নিয়ম: অডিও আর ছবির নাম একই (হাসি.mp3 + হাসি.jpg)।
 */
object AudioLibrary {
    class Item(val id: String, val name: String, val hasImg: Boolean)

    private val AUDIO = setOf("mp3", "wav", "ogg", "m4a", "aac", "flac", "opus", "amr", "3gp")
    private val IMAGE = setOf("jpg", "jpeg", "png", "webp")

    private fun prefs(c: Context) = c.getSharedPreferences("library", Context.MODE_PRIVATE)
    private fun dir(c: Context) = File(c.filesDir, "audio").apply { mkdirs() }
    fun file(c: Context, id: String) = File(dir(c), "$id.pcm")
    private fun img(c: Context, id: String) = File(dir(c), "$id.jpg")
    private fun newId() = UUID.randomUUID().toString().take(8)

    fun list(c: Context): List<Item> {
        val a = JSONArray(prefs(c).getString("items", "[]"))
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Item(o.getString("id"), o.getString("name"), o.optBoolean("img", false))
        }
    }

    private fun save(c: Context, items: List<Item>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().put("id", it.id).put("name", it.name).put("img", it.hasImg)) }
        prefs(c).edit().putString("items", a.toString()).apply()
    }

    @Synchronized
    private fun addItem(c: Context, item: Item) { save(c, list(c) + item) }

    fun thumb(c: Context, item: Item): Bitmap? =
        if (item.hasImg) try { BitmapFactory.decodeFile(img(c, item.id).path) } catch (_: Throwable) { null } else null

    fun displayName(c: Context, uri: Uri): String =
        c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { if (it.moveToFirst()) it.getString(0) else null } ?: "audio"

    /** একটা অডিও ফাইল যোগ করা */
    fun addFromUri(c: Context, uri: Uri): Item? {
        val name = displayName(c, uri).substringBeforeLast('.')
        if (list(c).any { it.name == name }) return null
        val id = newId()
        Decoder.decodeToPcm(c, uri, file(c, id))
        val item = Item(id, name, false)
        addItem(c, item)
        return item
    }

    private fun saveThumb(src: File, out: File): Boolean {
        try {
            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(src.path, opts)
            var s = 1
            while (opts.outWidth / (s * 2) >= 256 && opts.outHeight / (s * 2) >= 256) s *= 2
            val bm = BitmapFactory.decodeFile(src.path, BitmapFactory.Options().apply { inSampleSize = s }) ?: return false
            val side = minOf(bm.width, bm.height)
            val sq = Bitmap.createBitmap(bm, (bm.width - side) / 2, (bm.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, 128, 128, true)
            out.outputStream().use { sc.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            return true
        } catch (_: Throwable) {
            return false
        }
    }

    /** ZIP থেকে সব ভয়েস (ছবিসহ) যোগ করে। একই নামের ভয়েস আবার যোগ হয় না। */
    fun importZip(c: Context, open: () -> InputStream?, progress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val tmp = File(c.cacheDir, "zipimp").apply { deleteRecursively(); mkdirs() }
        val audios = LinkedHashMap<String, File>()
        val images = HashMap<String, File>()
        var idx = 0
        val raw = open() ?: return 0
        raw.use {
            ZipInputStream(BufferedInputStream(it)).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.isDirectory) continue
                    if (e.name.contains("__MACOSX")) continue
                    val fn = e.name.substringAfterLast('/')
                    if (fn.startsWith(".")) continue
                    val ext = fn.substringAfterLast('.', "").lowercase()
                    val base = fn.substringBeforeLast('.')
                    if (ext in AUDIO) {
                        val f = File(tmp, "a${idx++}.$ext")
                        f.outputStream().use { o -> zin.copyTo(o) }
                        audios[base] = f
                    } else if (ext in IMAGE) {
                        val f = File(tmp, "i${idx++}.$ext")
                        f.outputStream().use { o -> zin.copyTo(o) }
                        images[base] = f
                    }
                }
            }
        }
        val total = audios.size
        var done = 0
        var added = 0
        val existing = list(c).map { it.name }.toMutableSet()
        for ((base, af) in audios) {
            progress(done++, total)
            if (base in existing) continue
            try {
                val id = newId()
                Decoder.decodeFileToPcm(af, file(c, id))
                val imgFile = images[base]
                val has = imgFile != null && saveThumb(imgFile, img(c, id))
                addItem(c, Item(id, base, has))
                existing.add(base)
                added++
            } catch (_: Throwable) {}
        }
        progress(total, total)
        tmp.deleteRecursively()
        return added
    }

    /** অ্যাপের ভেতরে assets/voices.zip থাকলে নিজে থেকে যোগ করে (প্যাক বদলালে আবার)। */
    fun importBundled(c: Context, progress: (Int, Int) -> Unit = { _, _ -> }): Int {
        val names = c.assets.list("") ?: return 0
        if ("voices.zip" !in names) return 0
        var size = 0L
        c.assets.open("voices.zip").use {
            val b = ByteArray(65536)
            while (true) { val r = it.read(b); if (r < 0) break; size += r }
        }
        val sp = prefs(c)
        if (sp.getLong("bundled", -1L) == size) return 0
        val n = importZip(c, { c.assets.open("voices.zip") }, progress)
        sp.edit().putLong("bundled", size).apply()
        return n
    }

    fun remove(c: Context, id: String) {
        file(c, id).delete()
        img(c, id).delete()
        synchronized(this) { save(c, list(c).filter { it.id != id }) }
    }
}
