package com.codexayat.voice;
import android.os.ParcelFileDescriptor;

interface IAudioService {
    void destroy() = 16777114;
    String inject(in ParcelFileDescriptor pcm, int sampleRate) = 1;
    void stop() = 2;
}
